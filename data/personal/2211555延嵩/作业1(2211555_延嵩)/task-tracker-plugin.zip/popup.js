const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const todayTaskList = document.getElementById("todayTaskList");
const pastTaskList = document.getElementById("pastTaskList");
const todayTab = document.getElementById("todayTab");
const pastTab = document.getElementById("pastTab");
const todayPage = document.getElementById("todayPage");
const pastPage = document.getElementById("pastPage");

function getCurrentDate() {
  const today = new Date();
  const yyyy = today.getFullYear();
  let mm = today.getMonth() + 1; // Months are zero-based
  let dd = today.getDate();
  mm = mm < 10 ? '0' + mm : mm;
  dd = dd < 10 ? '0' + dd : dd;
  return `${yyyy}-${mm}-${dd}`;
}

function getDateOffset(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  const yyyy = date.getFullYear();
  let mm = date.getMonth() + 1;
  let dd = date.getDate();
  mm = mm < 10 ? '0' + mm : mm;
  dd = dd < 10 ? '0' + dd : dd;
  return `${yyyy}-${mm}-${dd}`;
}

// 切换页面显示
todayTab.addEventListener("click", () => {
  todayTab.classList.add("active");
  pastTab.classList.remove("active");
  todayPage.style.display = "block";
  pastPage.style.display = "none";
});

pastTab.addEventListener("click", () => {
  pastTab.classList.add("active");
  todayTab.classList.remove("active");
  pastPage.style.display = "block";
  todayPage.style.display = "none";
});

// 从 localStorage 获取任务并加载
function loadTasks() {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || {};
  const todayDate = getCurrentDate();
  const threeDaysAgo = getDateOffset(3);

  // 删除超过三天的任务
  Object.keys(tasks).forEach(date => {
    if (date < threeDaysAgo) {
      delete tasks[date];
    }
  });

  // 今日任务
  todayTaskList.innerHTML = '';
  if (tasks[todayDate]) {
    tasks[todayDate].forEach((task, index) => {
      const li = document.createElement("li");
      li.classList.add("taskItem");
      li.innerHTML = `
  <div class="taskMainRow">
    <span class="taskLabel">${task.name}</span>
    <input type="checkbox" class="checkboxBtn" ${task.completed ? "checked" : ""} data-date="${todayDate}" data-index="${index}" />
    <button class="deleteBtn" data-date="${todayDate}" data-index="${index}">删除</button>
    <button class="expandBtn" data-date="${todayDate}" data-index="${index}"></button>
  </div>
  <div class="taskLink" style="display:none;">${task.link || ''}</div>
`;
      todayTaskList.appendChild(li);
    });
  }

  // 往日任务（仅保留最近三天的任务）
  pastTaskList.innerHTML = '';
  Object.keys(tasks).forEach(date => {
    if (date !== todayDate && date >= threeDaysAgo) {
      tasks[date].forEach((task, index) => {
        const li = document.createElement("li");
        li.classList.add("taskItem");
        li.innerHTML = `
  <div class="taskMainRow">
    <span class="taskLabel">${task.name}</span>
    <input type="checkbox" class="checkboxBtn" ${task.completed ? "checked" : ""} data-date="${date}" data-index="${index}" />
    <button class="deleteBtn" data-date="${date}" data-index="${index}">删除</button>
    <button class="expandBtn" data-date="${date}" data-index="${index}"></button>
  </div>
  <div class="taskLink" style="display:none;">${task.link || ''}</div>
`;
        pastTaskList.appendChild(li);
      });
    }
  });
}

// 添加任务
function getCurrentTabUrl(callback) {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const url = tabs[0].url;
    callback(url);
  });
}

addTaskBtn.addEventListener("click", () => {
  const taskName = taskInput.value.trim();
  if (taskName) {
    getCurrentTabUrl(taskLink => {
      const tasks = JSON.parse(localStorage.getItem("tasks")) || {};
      const todayDate = getCurrentDate();
      if (!tasks[todayDate]) {
        tasks[todayDate] = [];
      }
      tasks[todayDate].push({ name: taskName, completed: false, link: taskLink });
      localStorage.setItem("tasks", JSON.stringify(tasks));
      taskInput.value = "";
      loadTasks();
    });
  }
});

// 标记任务完成/未完成
todayTaskList.addEventListener("change", (e) => {
  if (e.target.type === "checkbox") {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || {};
    const date = e.target.getAttribute("data-date");
    const taskIndex = e.target.getAttribute("data-index");
    tasks[date][taskIndex].completed = e.target.checked;
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }
});

// 修复展开任务链接逻辑
function toggleTaskLink(e) {
  if (e.target.classList.contains("expandBtn")) {
    const btn = e.target;
    const li = btn.closest(".taskItem");
    const linkDiv = li.querySelector(".taskLink");
    btn.classList.toggle("active");
    const isNowActive = btn.classList.contains("active");
    linkDiv.style.display = isNowActive ? "block" : "none";
  }
}

todayTaskList.addEventListener("click", toggleTaskLink);
pastTaskList.addEventListener("click", toggleTaskLink);

// 删除任务
todayTaskList.addEventListener("click", (e) => {
  if (e.target.classList.contains("deleteBtn")) {
    const date = e.target.getAttribute("data-date");
    const taskIndex = e.target.getAttribute("data-index");
    const tasks = JSON.parse(localStorage.getItem("tasks")) || {};
    tasks[date].splice(taskIndex, 1);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    loadTasks();
  }
});

pastTaskList.addEventListener("click", (e) => {
  if (e.target.classList.contains("deleteBtn")) {
    const date = e.target.getAttribute("data-date");
    const taskIndex = e.target.getAttribute("data-index");
    const tasks = JSON.parse(localStorage.getItem("tasks")) || {};
    tasks[date].splice(taskIndex, 1);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    loadTasks();
  }
});

// 初始加载任务
loadTasks();
